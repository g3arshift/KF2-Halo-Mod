This model was created from scratch using references by "Vince5754",
please give credit for use of my models in your project. Thanks!

https://vince5754.deviantart.com/

Specific notes for this model:

The M6D Magnum model includes the base model, as well as two attachments for
the Smart Link or SOCOM variants. There are two RGB Masks, with Green channel being
the Grip material, while the Blue channel is for the lights.